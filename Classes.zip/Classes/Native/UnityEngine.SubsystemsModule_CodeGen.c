﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.ISubsystemDescriptorImpl::set_ptr(System.IntPtr)
// 0x00000002 System.String UnityEngine.IntegratedSubsystemDescriptor::get_id()
extern void IntegratedSubsystemDescriptor_get_id_m79F62994737A858E9F906C33C1B43E68E1A7E01D (void);
// 0x00000003 System.Void UnityEngine.IntegratedSubsystemDescriptor::UnityEngine.ISubsystemDescriptorImpl.set_ptr(System.IntPtr)
extern void IntegratedSubsystemDescriptor_UnityEngine_ISubsystemDescriptorImpl_set_ptr_mF0879B9C36FB09E326538674E6594733253926B0 (void);
// 0x00000004 System.Void UnityEngine.IntegratedSubsystemDescriptor::.ctor()
extern void IntegratedSubsystemDescriptor__ctor_m1D87F86FF3A30C3ECCD95D1797802B34B9194039 (void);
// 0x00000005 System.String UnityEngine.SubsystemDescriptor::get_id()
extern void SubsystemDescriptor_get_id_m3C86DB10ED367BA8CCDEB1B82EA6259712BF3F4B (void);
// 0x00000006 System.Void UnityEngine.SubsystemDescriptor::set_id(System.String)
extern void SubsystemDescriptor_set_id_mA84B0580E0938F338B6E2A07BF02E893649A49FA (void);
// 0x00000007 System.Type UnityEngine.SubsystemDescriptor::get_subsystemImplementationType()
extern void SubsystemDescriptor_get_subsystemImplementationType_mCF20A5F2E10F34F73853FEC4D3893B49EB49C166 (void);
// 0x00000008 System.Void UnityEngine.SubsystemDescriptor::set_subsystemImplementationType(System.Type)
extern void SubsystemDescriptor_set_subsystemImplementationType_mAE7AE6B41C6BC0E59B6EC4E9BB6E93A98F4B7BF9 (void);
// 0x00000009 System.Void UnityEngine.SubsystemDescriptor::.ctor()
extern void SubsystemDescriptor__ctor_m36DDE5770481719052DCBDC48DC4494D886DE747 (void);
// 0x0000000A TSubsystem UnityEngine.IntegratedSubsystemDescriptor`1::Create()
// 0x0000000B System.Void UnityEngine.IntegratedSubsystemDescriptor`1::.ctor()
// 0x0000000C TSubsystem UnityEngine.SubsystemDescriptor`1::Create()
// 0x0000000D System.Void UnityEngine.SubsystemDescriptor`1::.ctor()
// 0x0000000E System.Void UnityEngine.Internal_SubsystemInstances::Internal_InitializeManagedInstance(System.IntPtr,UnityEngine.IntegratedSubsystem)
extern void Internal_SubsystemInstances_Internal_InitializeManagedInstance_m580E5BA46496BEC6C6F6470BEB469A2F7B2D88D8 (void);
// 0x0000000F System.Void UnityEngine.Internal_SubsystemInstances::Internal_ClearManagedInstances()
extern void Internal_SubsystemInstances_Internal_ClearManagedInstances_m32FCDDDBD4F6BFF0477C1DDC220F891F8846BC78 (void);
// 0x00000010 System.Void UnityEngine.Internal_SubsystemInstances::Internal_RemoveInstanceByPtr(System.IntPtr)
extern void Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_mC4C0FDB6FAA4DE872C42A4B62963286CDC110504 (void);
// 0x00000011 UnityEngine.IntegratedSubsystem UnityEngine.Internal_SubsystemInstances::Internal_GetInstanceByPtr(System.IntPtr)
extern void Internal_SubsystemInstances_Internal_GetInstanceByPtr_m2A3E2B194F743DA1505586132038FA64DF8FB407 (void);
// 0x00000012 System.Void UnityEngine.Internal_SubsystemInstances::Internal_AddStandaloneSubsystem(UnityEngine.Subsystem)
extern void Internal_SubsystemInstances_Internal_AddStandaloneSubsystem_m93A60FA6B3E9A106B424BB6051B2A553363BF051 (void);
// 0x00000013 UnityEngine.Subsystem UnityEngine.Internal_SubsystemInstances::Internal_FindStandaloneSubsystemInstanceGivenDescriptor(UnityEngine.SubsystemDescriptor)
extern void Internal_SubsystemInstances_Internal_FindStandaloneSubsystemInstanceGivenDescriptor_mD7E452AE994DB1342208053B8DEF0BC057A09F86 (void);
// 0x00000014 System.Void UnityEngine.Internal_SubsystemInstances::.cctor()
extern void Internal_SubsystemInstances__cctor_m7AEB2DE53CD2E30AC7172D0F626A01A42E3D8BC8 (void);
// 0x00000015 System.Boolean UnityEngine.Internal_SubsystemDescriptors::Internal_AddDescriptor(UnityEngine.SubsystemDescriptor)
extern void Internal_SubsystemDescriptors_Internal_AddDescriptor_m59AA86EDAB83ECDBB73BED4CDF9CAC0687FDD3E3 (void);
// 0x00000016 System.Void UnityEngine.Internal_SubsystemDescriptors::Internal_InitializeManagedDescriptor(System.IntPtr,UnityEngine.ISubsystemDescriptorImpl)
extern void Internal_SubsystemDescriptors_Internal_InitializeManagedDescriptor_mC79AAE7A1E1057D884878626695866E3771D6808 (void);
// 0x00000017 System.Void UnityEngine.Internal_SubsystemDescriptors::Internal_ClearManagedDescriptors()
extern void Internal_SubsystemDescriptors_Internal_ClearManagedDescriptors_m8CE3219D0FD13147A65CA2EA7BD7B988C8DEB8F9 (void);
// 0x00000018 System.IntPtr UnityEngine.Internal_SubsystemDescriptors::Create(System.IntPtr)
extern void Internal_SubsystemDescriptors_Create_mEB503EBC87BAE5D491C9FCD0C9D177881020EC99 (void);
// 0x00000019 System.String UnityEngine.Internal_SubsystemDescriptors::GetId(System.IntPtr)
extern void Internal_SubsystemDescriptors_GetId_m03C1E6E2C22F99C27DEE1D05326DE1E4E26B607A (void);
// 0x0000001A System.Void UnityEngine.Internal_SubsystemDescriptors::.cctor()
extern void Internal_SubsystemDescriptors__cctor_m149B8139233805E72A8AF98A4BEC43061CF170E5 (void);
// 0x0000001B System.Void UnityEngine.SubsystemManager::.cctor()
extern void SubsystemManager__cctor_m30894AE2CB9C3A21A7D7B157B9047DAE70C924CA (void);
// 0x0000001C System.Void UnityEngine.SubsystemManager::ReportSingleSubsystemAnalytics(System.String)
extern void SubsystemManager_ReportSingleSubsystemAnalytics_m8A2E7E994802B674E22CECEBDB8AB905E0A73EB4 (void);
// 0x0000001D System.Void UnityEngine.SubsystemManager::GetSubsystemDescriptors(System.Collections.Generic.List`1<T>)
// 0x0000001E System.Void UnityEngine.SubsystemManager::GetInstances(System.Collections.Generic.List`1<T>)
// 0x0000001F System.Void UnityEngine.SubsystemManager::DestroyInstance_Internal(System.IntPtr)
extern void SubsystemManager_DestroyInstance_Internal_m84B5A34CBA8CB913B58E2E2E7E741237607EE051 (void);
// 0x00000020 System.Void UnityEngine.SubsystemManager::StaticConstructScriptingClassMap()
extern void SubsystemManager_StaticConstructScriptingClassMap_m390BB17079E66AD3AD228FB161803EB6D58CBEF7 (void);
// 0x00000021 System.Void UnityEngine.SubsystemManager::Internal_ReloadSubsystemsStarted()
extern void SubsystemManager_Internal_ReloadSubsystemsStarted_mBD7C665A2208A4D054831CDE8EF453BD52EAB4BB (void);
// 0x00000022 System.Void UnityEngine.SubsystemManager::Internal_ReloadSubsystemsCompleted()
extern void SubsystemManager_Internal_ReloadSubsystemsCompleted_m38DD347051B33792BDFC4A06D4B527D0E007A7BB (void);
// 0x00000023 System.Void UnityEngine.IntegratedSubsystem::SetHandle(UnityEngine.IntegratedSubsystem)
extern void IntegratedSubsystem_SetHandle_mB733DA594EA535C6BB5E3F79387C518EE24AF8A4 (void);
// 0x00000024 System.Void UnityEngine.IntegratedSubsystem::Start()
extern void IntegratedSubsystem_Start_m37CC4D2EEF19F87CC187680C29AADAB07B502786 (void);
// 0x00000025 System.Void UnityEngine.IntegratedSubsystem::Stop()
extern void IntegratedSubsystem_Stop_m3A7F5B736EF2209500BE0A3EA463B77DAB2CECAF (void);
// 0x00000026 System.Void UnityEngine.IntegratedSubsystem::Destroy()
extern void IntegratedSubsystem_Destroy_mB7476F3A7D56311C9A05D428CE8D378A71BEFD5D (void);
// 0x00000027 System.Boolean UnityEngine.IntegratedSubsystem::get_running()
extern void IntegratedSubsystem_get_running_m39FED0A48B27096E2957169B19712DFA11877624 (void);
// 0x00000028 System.Boolean UnityEngine.IntegratedSubsystem::get_valid()
extern void IntegratedSubsystem_get_valid_mEB7685D79E82783866E96A2B3C1145868D8179EF (void);
// 0x00000029 System.Boolean UnityEngine.IntegratedSubsystem::Internal_IsRunning()
extern void IntegratedSubsystem_Internal_IsRunning_m6473A064999C281A759E076BE65C16A0DB45A288 (void);
// 0x0000002A System.Void UnityEngine.IntegratedSubsystem::.ctor()
extern void IntegratedSubsystem__ctor_mDBF83DF7F1F0B6DB1C64DD2C585E8A0CC7EE0EF1 (void);
// 0x0000002B System.Void UnityEngine.IntegratedSubsystem`1::.ctor()
// 0x0000002C System.Void UnityEngine.Subsystem::Start()
// 0x0000002D System.Void UnityEngine.Subsystem::Stop()
// 0x0000002E System.Void UnityEngine.Subsystem::Destroy()
extern void Subsystem_Destroy_m1D65C2E3B540A9EC80E14BF0C7A2BE8CDCF887A4 (void);
// 0x0000002F System.Boolean UnityEngine.Subsystem::get_running()
// 0x00000030 System.Void UnityEngine.Subsystem::OnDestroy()
// 0x00000031 System.Void UnityEngine.Subsystem::.ctor()
extern void Subsystem__ctor_m00FD26014DE966433A871B78ED54389E8DC59E94 (void);
// 0x00000032 TSubsystemDescriptor UnityEngine.Subsystem`1::get_SubsystemDescriptor()
// 0x00000033 System.Void UnityEngine.Subsystem`1::.ctor()
static Il2CppMethodPointer s_methodPointers[51] = 
{
	NULL,
	IntegratedSubsystemDescriptor_get_id_m79F62994737A858E9F906C33C1B43E68E1A7E01D,
	IntegratedSubsystemDescriptor_UnityEngine_ISubsystemDescriptorImpl_set_ptr_mF0879B9C36FB09E326538674E6594733253926B0,
	IntegratedSubsystemDescriptor__ctor_m1D87F86FF3A30C3ECCD95D1797802B34B9194039,
	SubsystemDescriptor_get_id_m3C86DB10ED367BA8CCDEB1B82EA6259712BF3F4B,
	SubsystemDescriptor_set_id_mA84B0580E0938F338B6E2A07BF02E893649A49FA,
	SubsystemDescriptor_get_subsystemImplementationType_mCF20A5F2E10F34F73853FEC4D3893B49EB49C166,
	SubsystemDescriptor_set_subsystemImplementationType_mAE7AE6B41C6BC0E59B6EC4E9BB6E93A98F4B7BF9,
	SubsystemDescriptor__ctor_m36DDE5770481719052DCBDC48DC4494D886DE747,
	NULL,
	NULL,
	NULL,
	NULL,
	Internal_SubsystemInstances_Internal_InitializeManagedInstance_m580E5BA46496BEC6C6F6470BEB469A2F7B2D88D8,
	Internal_SubsystemInstances_Internal_ClearManagedInstances_m32FCDDDBD4F6BFF0477C1DDC220F891F8846BC78,
	Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_mC4C0FDB6FAA4DE872C42A4B62963286CDC110504,
	Internal_SubsystemInstances_Internal_GetInstanceByPtr_m2A3E2B194F743DA1505586132038FA64DF8FB407,
	Internal_SubsystemInstances_Internal_AddStandaloneSubsystem_m93A60FA6B3E9A106B424BB6051B2A553363BF051,
	Internal_SubsystemInstances_Internal_FindStandaloneSubsystemInstanceGivenDescriptor_mD7E452AE994DB1342208053B8DEF0BC057A09F86,
	Internal_SubsystemInstances__cctor_m7AEB2DE53CD2E30AC7172D0F626A01A42E3D8BC8,
	Internal_SubsystemDescriptors_Internal_AddDescriptor_m59AA86EDAB83ECDBB73BED4CDF9CAC0687FDD3E3,
	Internal_SubsystemDescriptors_Internal_InitializeManagedDescriptor_mC79AAE7A1E1057D884878626695866E3771D6808,
	Internal_SubsystemDescriptors_Internal_ClearManagedDescriptors_m8CE3219D0FD13147A65CA2EA7BD7B988C8DEB8F9,
	Internal_SubsystemDescriptors_Create_mEB503EBC87BAE5D491C9FCD0C9D177881020EC99,
	Internal_SubsystemDescriptors_GetId_m03C1E6E2C22F99C27DEE1D05326DE1E4E26B607A,
	Internal_SubsystemDescriptors__cctor_m149B8139233805E72A8AF98A4BEC43061CF170E5,
	SubsystemManager__cctor_m30894AE2CB9C3A21A7D7B157B9047DAE70C924CA,
	SubsystemManager_ReportSingleSubsystemAnalytics_m8A2E7E994802B674E22CECEBDB8AB905E0A73EB4,
	NULL,
	NULL,
	SubsystemManager_DestroyInstance_Internal_m84B5A34CBA8CB913B58E2E2E7E741237607EE051,
	SubsystemManager_StaticConstructScriptingClassMap_m390BB17079E66AD3AD228FB161803EB6D58CBEF7,
	SubsystemManager_Internal_ReloadSubsystemsStarted_mBD7C665A2208A4D054831CDE8EF453BD52EAB4BB,
	SubsystemManager_Internal_ReloadSubsystemsCompleted_m38DD347051B33792BDFC4A06D4B527D0E007A7BB,
	IntegratedSubsystem_SetHandle_mB733DA594EA535C6BB5E3F79387C518EE24AF8A4,
	IntegratedSubsystem_Start_m37CC4D2EEF19F87CC187680C29AADAB07B502786,
	IntegratedSubsystem_Stop_m3A7F5B736EF2209500BE0A3EA463B77DAB2CECAF,
	IntegratedSubsystem_Destroy_mB7476F3A7D56311C9A05D428CE8D378A71BEFD5D,
	IntegratedSubsystem_get_running_m39FED0A48B27096E2957169B19712DFA11877624,
	IntegratedSubsystem_get_valid_mEB7685D79E82783866E96A2B3C1145868D8179EF,
	IntegratedSubsystem_Internal_IsRunning_m6473A064999C281A759E076BE65C16A0DB45A288,
	IntegratedSubsystem__ctor_mDBF83DF7F1F0B6DB1C64DD2C585E8A0CC7EE0EF1,
	NULL,
	NULL,
	NULL,
	Subsystem_Destroy_m1D65C2E3B540A9EC80E14BF0C7A2BE8CDCF887A4,
	NULL,
	NULL,
	Subsystem__ctor_m00FD26014DE966433A871B78ED54389E8DC59E94,
	NULL,
	NULL,
};
static const int32_t s_InvokerIndices[51] = 
{
	7,
	14,
	7,
	23,
	14,
	26,
	14,
	26,
	23,
	-1,
	-1,
	-1,
	-1,
	1282,
	3,
	25,
	18,
	111,
	0,
	3,
	109,
	1282,
	3,
	1283,
	18,
	3,
	3,
	111,
	-1,
	-1,
	25,
	3,
	3,
	3,
	26,
	23,
	23,
	23,
	102,
	102,
	102,
	23,
	-1,
	23,
	23,
	23,
	102,
	23,
	23,
	-1,
	-1,
};
static const Il2CppTokenRangePair s_rgctxIndices[5] = 
{
	{ 0x02000006, { 0, 1 } },
	{ 0x02000007, { 1, 1 } },
	{ 0x0200000F, { 8, 1 } },
	{ 0x0600001D, { 2, 3 } },
	{ 0x0600001E, { 5, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[9] = 
{
	{ (Il2CppRGCTXDataType)2, 13928 },
	{ (Il2CppRGCTXDataType)2, 13931 },
	{ (Il2CppRGCTXDataType)3, 12204 },
	{ (Il2CppRGCTXDataType)2, 13943 },
	{ (Il2CppRGCTXDataType)3, 12205 },
	{ (Il2CppRGCTXDataType)3, 12206 },
	{ (Il2CppRGCTXDataType)2, 13945 },
	{ (Il2CppRGCTXDataType)3, 12207 },
	{ (Il2CppRGCTXDataType)2, 13954 },
};
extern const Il2CppCodeGenModule g_UnityEngine_SubsystemsModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_SubsystemsModuleCodeGenModule = 
{
	"UnityEngine.SubsystemsModule.dll",
	51,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	5,
	s_rgctxIndices,
	9,
	s_rgctxValues,
	NULL,
};
