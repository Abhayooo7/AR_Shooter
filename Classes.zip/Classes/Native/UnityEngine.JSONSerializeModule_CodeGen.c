﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.JsonUtility::ToJsonInternal(System.Object,System.Boolean)
extern void JsonUtility_ToJsonInternal_m9BE2809ED2EE4486F4636C638F60342849ED9C7D (void);
// 0x00000002 System.Object UnityEngine.JsonUtility::FromJsonInternal(System.String,System.Object,System.Type)
extern void JsonUtility_FromJsonInternal_mE4EF48FC77B4B25155BB039E477D4181E9E55E69 (void);
// 0x00000003 System.String UnityEngine.JsonUtility::ToJson(System.Object)
extern void JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573 (void);
// 0x00000004 System.String UnityEngine.JsonUtility::ToJson(System.Object,System.Boolean)
extern void JsonUtility_ToJson_m7726F8B90F5F4049147B9463CC08672A29B603FA (void);
// 0x00000005 T UnityEngine.JsonUtility::FromJson(System.String)
// 0x00000006 System.Object UnityEngine.JsonUtility::FromJson(System.String,System.Type)
extern void JsonUtility_FromJson_mD891C9EDB2D0B95536CD2A3F2BEFF3DCFEE30A45 (void);
static Il2CppMethodPointer s_methodPointers[6] = 
{
	JsonUtility_ToJsonInternal_m9BE2809ED2EE4486F4636C638F60342849ED9C7D,
	JsonUtility_FromJsonInternal_mE4EF48FC77B4B25155BB039E477D4181E9E55E69,
	JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573,
	JsonUtility_ToJson_m7726F8B90F5F4049147B9463CC08672A29B603FA,
	NULL,
	JsonUtility_FromJson_mD891C9EDB2D0B95536CD2A3F2BEFF3DCFEE30A45,
};
static const int32_t s_InvokerIndices[6] = 
{
	110,
	2,
	0,
	110,
	-1,
	1,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000005, { 0, 2 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[2] = 
{
	{ (Il2CppRGCTXDataType)1, 14667 },
	{ (Il2CppRGCTXDataType)2, 14667 },
};
extern const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule = 
{
	"UnityEngine.JSONSerializeModule.dll",
	6,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	2,
	s_rgctxValues,
	NULL,
};
