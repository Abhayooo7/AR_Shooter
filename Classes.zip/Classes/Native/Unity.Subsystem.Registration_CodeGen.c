﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Boolean UnityEngine.SubsystemRegistration::CreateDescriptor(UnityEngine.SubsystemDescriptor)
extern void SubsystemRegistration_CreateDescriptor_mF8C5F6E0433D832FE0F1BDBD966B09C2A8283C9D (void);
// 0x00000002 System.Void UnityEngine.SubsystemRegistration::.cctor()
extern void SubsystemRegistration__cctor_mCB098CD1DEBC3583659DF14C060CCE1050A4105C (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	SubsystemRegistration_CreateDescriptor_mF8C5F6E0433D832FE0F1BDBD966B09C2A8283C9D,
	SubsystemRegistration__cctor_mCB098CD1DEBC3583659DF14C060CCE1050A4105C,
};
static const int32_t s_InvokerIndices[2] = 
{
	109,
	3,
};
extern const Il2CppCodeGenModule g_Unity_Subsystem_RegistrationCodeGenModule;
const Il2CppCodeGenModule g_Unity_Subsystem_RegistrationCodeGenModule = 
{
	"Unity.Subsystem.Registration.dll",
	2,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
