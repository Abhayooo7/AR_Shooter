#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    class LIBIL2CPP_CODEGEN_API CLRConfig
    {
    public:
        static bool CheckThrowUnobservedTaskExceptions();
    };
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
