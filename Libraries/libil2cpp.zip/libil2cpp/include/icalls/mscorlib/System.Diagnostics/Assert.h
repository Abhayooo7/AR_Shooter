#pragma once
namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
namespace Diagnostics
{
    class LIBIL2CPP_CODEGEN_API Assert
    {
    public:
        static int32_t ShowDefaultAssertDialog(Il2CppString* conditionString, Il2CppString* message, Il2CppString* stackTrace, Il2CppString* windowTitle);
    };
} // namespace Diagnostics
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
