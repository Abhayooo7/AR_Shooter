#pragma once

namespace il2cpp
{
namespace os
{
    void InitializeDllMain();
}
}
